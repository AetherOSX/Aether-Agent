[@elizaos/core v0.1.7-alpha.1](../index.md) / defaultCharacter

# Variable: defaultCharacter

> `const` **defaultCharacter**: [`Character`](../type-aliases/Character.md)

## Defined in

[packages/core/src/defaultCharacter.ts:3](https://github.com/elizaOS/eliza/blob/main/packages/core/src/defaultCharacter.ts#L3)
