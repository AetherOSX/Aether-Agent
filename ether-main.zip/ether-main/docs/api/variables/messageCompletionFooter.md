[@elizaos/core v0.1.7-alpha.1](../index.md) / messageCompletionFooter

# Variable: messageCompletionFooter

> `const` **messageCompletionFooter**: "\nResponse format should be formatted in a JSON block like this:\n\`\`\`json\n\{ \"user\": \"\{\{agentName\}\}\", \"text\": \"string\", \"action\": \"string\" \}\n\`\`\`"

## Defined in

[packages/core/src/parsing.ts:4](https://github.com/elizaOS/eliza/blob/main/packages/core/src/parsing.ts#L4)
