[@elizaos/core v0.1.7-alpha.1](../index.md) / settings

# Variable: settings

> `const` **settings**: `Settings`

Initialize settings based on environment

## Defined in

[packages/core/src/settings.ts:126](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L126)
