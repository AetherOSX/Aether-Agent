[@elizaos/core v0.1.7-alpha.1](../index.md) / IAgentConfig

# Interface: IAgentConfig

## Indexable

 \[`key`: `string`\]: `string`
