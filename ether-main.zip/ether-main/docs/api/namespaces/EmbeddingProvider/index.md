[@elizaos/core v0.1.7-alpha.1](../../index.md) / EmbeddingProvider

# EmbeddingProvider

## Index

### Type Aliases

- [OpenAI](type-aliases/OpenAI.md)
- [Ollama](type-aliases/Ollama.md)
- [GaiaNet](type-aliases/GaiaNet.md)
- [BGE](type-aliases/BGE.md)
