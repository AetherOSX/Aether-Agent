[@elizaos/core v0.1.7-alpha.1](../../../index.md) / [EmbeddingProvider](../index.md) / BGE

# Type Alias: BGE

> **BGE**: *typeof* `EmbeddingProvider.BGE`

## Defined in

[packages/core/src/embedding.ts:31](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L31)
