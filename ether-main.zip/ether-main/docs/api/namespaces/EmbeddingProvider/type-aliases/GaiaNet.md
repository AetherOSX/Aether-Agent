[@elizaos/core v0.1.7-alpha.1](../../../index.md) / [EmbeddingProvider](../index.md) / GaiaNet

# Type Alias: GaiaNet

> **GaiaNet**: *typeof* `EmbeddingProvider.GaiaNet`

## Defined in

[packages/core/src/embedding.ts:30](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L30)
