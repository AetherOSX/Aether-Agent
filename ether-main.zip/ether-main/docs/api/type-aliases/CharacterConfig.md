[@elizaos/core v0.1.7-alpha.1](../index.md) / CharacterConfig

# Type Alias: CharacterConfig

> **CharacterConfig**: `z.infer`\<*typeof* [`CharacterSchema`](../variables/CharacterSchema.md)\>

Type inference

## Defined in

[packages/core/src/environment.ts:135](https://github.com/elizaOS/eliza/blob/main/packages/core/src/environment.ts#L135)
