[@elizaos/core v0.1.7-alpha.1](../index.md) / generateObjectArray

# Function: generateObjectArray()

> **generateObjectArray**(`__namedParameters`): `Promise`\<`any`[]\>

## Parameters

• **\_\_namedParameters**

• **\_\_namedParameters.runtime**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

• **\_\_namedParameters.context**: `string`

• **\_\_namedParameters.modelClass**: `string`

## Returns

`Promise`\<`any`[]\>

## Defined in

[packages/core/src/generation.ts:837](https://github.com/elizaOS/eliza/blob/main/packages/core/src/generation.ts#L837)
