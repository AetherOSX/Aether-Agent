[@elizaos/core v0.1.7-alpha.1](../index.md) / parseBooleanFromText

# Function: parseBooleanFromText()

> **parseBooleanFromText**(`text`): `boolean`

## Parameters

• **text**: `string`

## Returns

`boolean`

## Defined in

[packages/core/src/parsing.ts:37](https://github.com/elizaOS/eliza/blob/main/packages/core/src/parsing.ts#L37)
