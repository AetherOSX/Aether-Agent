[@elizaos/core v0.1.7-alpha.1](../index.md) / getEmbeddingType

# Function: getEmbeddingType()

> **getEmbeddingType**(`runtime`): `"local"` \| `"remote"`

## Parameters

• **runtime**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

## Returns

`"local"` \| `"remote"`

## Defined in

[packages/core/src/embedding.ts:121](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L121)
