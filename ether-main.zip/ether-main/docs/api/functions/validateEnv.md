[@elizaos/core v0.1.7-alpha.1](../index.md) / validateEnv

# Function: validateEnv()

> **validateEnv**(): [`EnvConfig`](../type-aliases/EnvConfig.md)

Validation function

## Returns

[`EnvConfig`](../type-aliases/EnvConfig.md)

## Defined in

[packages/core/src/environment.ts:26](https://github.com/elizaOS/eliza/blob/main/packages/core/src/environment.ts#L26)
