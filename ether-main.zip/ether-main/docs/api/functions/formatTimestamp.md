[@elizaos/core v0.1.7-alpha.1](../index.md) / formatTimestamp

# Function: formatTimestamp()

> **formatTimestamp**(`messageDate`): `string`

## Parameters

• **messageDate**: `number`

## Returns

`string`

## Defined in

[packages/core/src/messages.ts:94](https://github.com/elizaOS/eliza/blob/main/packages/core/src/messages.ts#L94)
