[@elizaos/core v0.1.7-alpha.1](../index.md) / getEmbeddingConfig

# Function: getEmbeddingConfig()

> **getEmbeddingConfig**(): [`EmbeddingConfig`](../type-aliases/EmbeddingConfig.md)

## Returns

[`EmbeddingConfig`](../type-aliases/EmbeddingConfig.md)

## Defined in

[packages/core/src/embedding.ts:40](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L40)
