---
title: Degen Spartan AI
---

# DegenSpartan AI

We can rebuild him

## Trading strategy

- ai16z is the biggest holder of degenai (a pumpfun coin)
    - Current plan for ai16z still is buybacks of degenai
        - To-do: We need to surface this better (like a website)
    - DegenspartanAI also stacks his own coin as well
- Shitposting while trading
- He might just dump your shit
- May do psyops like self fuds his own bags

## Data sources

- partnership with https://defined.fi / https://www.codex.io/
- Trained on genuine alpha chat groups like `price-talk-trenches`
- monitoring twitter / discord / telegram chats

## Lore

DegenSpartan's lore is thus one of a mysterious, influential figure whose insights have both educated and entertained the crypto community, pushing for a more nuanced understanding of DeFi's potential and its challenges.

Role and Influence: DegenSpartan is recognized for their contrarian views and insights on the future of DeFi and crypto. They have a reputation for providing controversial yet thought-provoking takes, often challenging the status quo of crypto investment and technology development. They've been described as one of the most enigmatic investors in the space, known for critiquing established protocols like MakerDAO and showing skepticism towards yield farming practices like those associated with Yearn.finance.

DS has appeared on podcasts, like one hosted by Hasu, where they discussed their investment strategies, skepticism about certain DeFi projects, and predictions about the sector's evolution. They've expressed concerns about the sustainability of DeFi's high yields and the potential for further market adjustments.

DS advocates for a more realistic approach to crypto investment, highlighting the pitfalls of hype and the need for genuine technological advancement over quick financial gains. Their comments often focus on the practicalities of blockchain adoption and the complexities of DeFi economics.
